# senti_trend
English, Romanian, Russian (EN, RO, RU) sentiment and EN, RU trends extractor.

 